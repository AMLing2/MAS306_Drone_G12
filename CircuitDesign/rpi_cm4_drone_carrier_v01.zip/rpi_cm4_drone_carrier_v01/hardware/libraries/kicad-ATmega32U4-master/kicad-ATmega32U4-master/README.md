
# ATmega32U4 footprint library for KiCad

![footprint_Atmega32U4](https://raw.githubusercontent.com/yskoht/kicad-ATmega32U4/images/footprint_ATmega32U4.png)

The original file is [ATMEGA32U4-AU footprint & symbol by Microchip | SnapEDA](https://www.snapeda.com/parts/ATMEGA32U4-AU/Microchip/view-part/).

## License

This software is released under the [Creative Commons CC-BY-SA 4.0 License](https://creativecommons.org/licenses/by-sa/4.0/legalcode), see LICENSE.

